//
//  NewFrameworkZhassulan.h
//  NewFrameworkZhassulan
//
//  Created by Zhassulan Aimukhambetov on 10/23/19.
//  Copyright © 2019 Zhassulan Aimukhambetov. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for NewFrameworkZhassulan.
FOUNDATION_EXPORT double NewFrameworkZhassulanVersionNumber;

//! Project version string for NewFrameworkZhassulan.
FOUNDATION_EXPORT const unsigned char NewFrameworkZhassulanVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <NewFrameworkZhassulan/PublicHeader.h>


