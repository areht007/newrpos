//
//  GithubOAuthFramework.h
//  GithubOAuthFramework
//
//  Created by Zhassulan Aimukhambetov on 10/23/19.
//  Copyright © 2019 Zhassulan Aimukhambetov. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for GithubOAuthFramework.
FOUNDATION_EXPORT double GithubOAuthFrameworkVersionNumber;

//! Project version string for GithubOAuthFramework.
FOUNDATION_EXPORT const unsigned char GithubOAuthFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <GithubOAuthFramework/PublicHeader.h>


